
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Andres
 */
public class Ejercicio2 {

    public static void main(String[] args) throws IOException {

        BufferedReader cp = new BufferedReader(new InputStreamReader(System.in));

        edad ObjetoLista = new edad();

        int opcion;
        int dato;
        do {

            System.out.println("\n--- Asignación de notas ---\n");
            System.out.println("1. Ingrese la edad al inicio");
            System.out.println("2. Ingresar la edad al final");
            System.out.println("3. Eliminar la edad del inicio");
            System.out.println("4. Eliminar la edad del final");
            System.out.println("5. Mostrar Lista");
            System.out.println("6. Mostrar promedio edad");
            System.out.println("7. Mostrar maximo");
            System.out.println("8. Mostrar minimo");               
            System.out.println("0. Salir");

            System.out.println("\nIngrese la opción deseada: ");
            opcion = Integer.parseInt(cp.readLine());

            switch (opcion) {

                case 1:
                    System.out.println("\nDigite la edad a ingresar en la lista: ");
                    dato = Integer.parseInt(cp.readLine());
                    ObjetoLista.aggInicio(dato);
                    break;

                case 2:
                    System.out.println("\nDigite la edad a ingresar en la lista: ");
                    dato = Integer.parseInt(cp.readLine());
                    ObjetoLista.aggFinal(dato);
                    break;

                case 3:

                    System.out.println("\nEliminando en el inicio... ");
                    ObjetoLista.EliminarInicioLista();

                    break;
                case 4:

                    System.out.println("\nEliminando en el final... ");
                    ObjetoLista.EliminarFinalLista();

                    break;                    

                case 5:
                    ObjetoLista.mostrarInicioFin();
                    break;
                    
                case 6:
                    System.out.println("\nLa edad promedio es: "+ ObjetoLista.promedio());
                    break;                    

                case 7:
                    
                    
                    System.out.println("\nLa edad maxima es: "+ ObjetoLista.mayor());
                    break;                     

                case 8:
                    System.out.println("\nLa edad minima es: "+ ObjetoLista.menor());
                    break;      
                    
                case 0:
                    System.out.println("Hasta Pronto");
                    break;                            
            }
        } while (opcion != 0);

    }

}
