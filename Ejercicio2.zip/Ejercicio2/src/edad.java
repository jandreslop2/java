
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Andres
 */
public class edad {

    nodo inicio;
    nodo fin;

    public boolean estVacia() {
        return inicio == null;
    }

    public void aggFinal(int ele) {
        if (!estVacia()) {
            fin = new nodo(ele, null, fin);
            fin.anterior.siguiente = fin;
        } else {
            inicio = fin = new nodo(ele);
        }
    }

    public void aggInicio(int ele) {
        if (!estVacia()) {
            inicio = new nodo(ele, inicio, null);
            inicio.siguiente.anterior = inicio;

        } else {
            fin = inicio = new nodo(ele);
        }
    }

    public int mayor() {
        int mayor = 0;
        nodo recorrer = inicio;
        while (recorrer != null) {
            if (inicio.dato > mayor) {
                mayor = inicio.dato;
                inicio = inicio.siguiente;
            }
            recorrer = recorrer.siguiente;
        }
        return mayor;
    }

    public int menor() {
        int menor = 10000000;
        nodo recorrer = inicio;
        while (recorrer != null) {
            if (inicio.dato < menor) {
                menor = inicio.dato;
                inicio = inicio.siguiente;
            }
            recorrer = recorrer.siguiente;
        }
 
        return menor;
    }

    public int promedio() {
        nodo recorrer = inicio;
        int contador = 0;
        int acumulador = 0;
        int promedio;
        while (recorrer != null) {
            contador++;
            acumulador = acumulador + recorrer.dato;
            recorrer = recorrer.siguiente;
        }
        return promedio = (acumulador/contador);

    }

    public int EliminarInicioLista() {

        int elemento = inicio.dato;

        if (inicio == fin) {

            inicio = fin = null;

        } else {

            inicio = inicio.siguiente;

        }

        return elemento;
    }

    public int EliminarFinalLista() {

        int elemento = fin.dato;

        if (inicio == fin) {

            inicio = fin = null;

        } else {

            nodo Auxiliar = inicio;

            while (Auxiliar.siguiente != fin) {

                Auxiliar = Auxiliar.siguiente;

            }

            fin = Auxiliar;
            fin.siguiente = null;

        }

        return elemento;

    }

    public void mostrarInicioFin() {
        if (!estVacia()) {
            String datos = "<==>";
            nodo auxiliar = inicio;

            while (auxiliar != null) {
                datos = datos + "[" + auxiliar.dato + "]";
                auxiliar = auxiliar.siguiente;
            }
            JOptionPane.showMessageDialog(null, datos, "Mostrando lista, de inicio a fin",
                    JOptionPane.INFORMATION_MESSAGE);

        } else {
            JOptionPane.showMessageDialog(null, null, "La lista esta vacia ",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
